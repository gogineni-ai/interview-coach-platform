# Interview Coach Platform

A full-stack interview practice application that analyzes a resume, generates mock questions, listens through the browser microphone, detects interviewer questions, and produces concise resume-grounded coaching.

## Features

- Email/password registration and login with JWT authentication
- PDF, DOCX, and TXT resume upload and text extraction
- AI resume summary, skills, strengths, and improvement suggestions
- Role-specific mock behavioral and technical interview questions
- Browser microphone transcription using the Web Speech API
- Live question detection from transcripts
- Resume-grounded STAR-style answer coaching
- OpenAI-backed generation when `OPENAI_API_KEY` is set, with useful local fallbacks
- SQLite persistence for users and resumes

> Use this app for transparent practice and preparation. During a real interview, follow the employer's rules and obtain consent before recording or transcribing anyone.

## Stack

- Frontend: React 18, Vite, React Router, Axios
- Backend: FastAPI, SQLAlchemy, JWT, passlib/bcrypt, pypdf, python-docx

## Quick start

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp ../.env.example .env
uvicorn app.main:app --reload --port 8000
```

API documentation: http://localhost:8000/docs

### Frontend

```bash
cd frontend
npm install
cp ../.env.example .env
npm run dev
```

Open http://localhost:5173.

## Environment variables

| Variable | Purpose |
|---|---|
| `SECRET_KEY` | Signs authentication tokens; replace in production |
| `OPENAI_API_KEY` | Optional; enables AI analysis, questions, and coaching |
| `OPENAI_MODEL` | Model name; defaults to `gpt-4.1-mini` |
| `FRONTEND_ORIGIN` | Allowed browser origin for the API |
| `VITE_API_URL` | Frontend's backend base URL |

## Production notes

- Replace SQLite with PostgreSQL for multi-instance deployment.
- Use HTTPS, a strong `SECRET_KEY`, secure secret storage, rate limiting, and a retention policy for resumes/transcripts.
- Browser speech recognition works best in Chromium-based browsers and may use the browser vendor's speech service.

