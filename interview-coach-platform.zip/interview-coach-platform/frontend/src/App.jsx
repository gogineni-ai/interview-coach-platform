import { useEffect, useRef, useState } from "react";
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";
import api from "./api";

const errorText = (error) => error.response?.data?.detail || error.message || "Something went wrong";

function Auth({ mode }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const register = mode === "register";
  const submit = async (event) => {
    event.preventDefault(); setError("");
    try {
      const { data } = await api.post(`/auth/${mode}`, form);
      localStorage.setItem("token", data.access_token);
      navigate("/");
    } catch (err) { setError(errorText(err)); }
  };
  return <main className="auth-shell">
    <section className="auth-copy"><span className="eyebrow">PRIVATE PRACTICE STUDIO</span><h1>Turn your experience into answers that land.</h1><p>Resume-aware preparation, live question detection, and practical answer coaching in one focused workspace.</p></section>
    <form className="auth-card" onSubmit={submit}><div className="logo">IC</div><h2>{register ? "Create your account" : "Welcome back"}</h2><p>{register ? "Start a new coaching workspace." : "Continue your interview preparation."}</p>
      <label>Email<input type="email" required value={form.email} onChange={e => setForm({...form, email:e.target.value})} /></label>
      <label>Password<input type="password" minLength="8" required value={form.password} onChange={e => setForm({...form, password:e.target.value})} /></label>
      {error && <div className="error">{error}</div>}<button className="primary">{register ? "Register" : "Log in"}</button>
      <button type="button" className="text-button" onClick={() => navigate(register ? "/login" : "/register")}>{register ? "Already registered? Log in" : "New here? Create an account"}</button>
    </form>
  </main>;
}

function Dashboard({ logout }) {
  const [resume, setResume] = useState(null), [role, setRole] = useState("Software Engineer"), [questions, setQuestions] = useState([]);
  const [transcript, setTranscript] = useState(""), [question, setQuestion] = useState(""), [draft, setDraft] = useState(""), [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(""), [error, setError] = useState(""), recognition = useRef(null);
  useEffect(() => { api.get("/resume/latest").then(r => setResume(r.data)).catch(() => {}); }, []);
  const run = async (name, fn) => { setBusy(name); setError(""); try { await fn(); } catch (e) { setError(errorText(e)); } finally { setBusy(""); } };
  const upload = (file) => run("upload", async () => { const body = new FormData(); body.append("file", file); const {data}=await api.post("/resume/upload", body); setResume(data); });
  const generate = () => run("questions", async () => { const {data}=await api.post("/interview/questions", {target_role:role,count:8}); setQuestions(data.questions); });
  const detect = (text=transcript) => run("detect", async () => { const {data}=await api.post("/interview/detect-question", {transcript:text}); if(data.question) setQuestion(data.question); });
  const coach = () => run("coach", async () => { const {data}=await api.post("/interview/coach", {question,draft_answer:draft,target_role:role}); setAnswer(data.answer); });
  const listen = () => {
    const Speech = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Speech) return setError("Speech recognition is not supported in this browser. Try Chrome or Edge.");
    const rec = new Speech(); rec.continuous=true; rec.interimResults=true; rec.lang="en-US";
    rec.onresult = (event) => { let text=""; for(let i=0;i<event.results.length;i++) text += event.results[i][0].transcript + " "; setTranscript(text.trim()); };
    rec.onerror = (event) => setError(`Microphone error: ${event.error}`); rec.start(); recognition.current=rec; setBusy("listening");
  };
  const stop = () => { recognition.current?.stop(); recognition.current=null; setBusy(""); if(transcript) detect(transcript); };
  return <div className="app-shell"><header><div className="brand"><span>IC</span> Interview Coach</div><div className="status">● Practice workspace</div><button className="ghost" onClick={logout}>Log out</button></header>
    <main className="dashboard"><section className="hero"><div><span className="eyebrow">PERSONALIZED PREPARATION</span><h1>Build answers from your real experience.</h1><p>Upload your resume, practice targeted questions, and turn a live transcript into clear coaching.</p></div><div className="role"><label>Target role<input value={role} onChange={e=>setRole(e.target.value)} /></label><button className="primary" disabled={!resume||!!busy} onClick={generate}>{busy==="questions"?"Generating…":"Generate interview"}</button></div></section>
    {error && <div className="error banner">{error}</div>}
    <div className="grid"><section className="card"><div className="step">01</div><h2>Resume intelligence</h2><p className="muted">PDF, DOCX, or TXT · 5 MB maximum</p><label className="drop"><input type="file" accept=".pdf,.docx,.txt" onChange={e=>e.target.files[0]&&upload(e.target.files[0])}/><b>{busy==="upload"?"Analyzing…":resume?.filename||"Choose your resume"}</b><span>Click to upload</span></label>
      {resume?.analysis && <div className="analysis"><p>{resume.analysis.summary}</p><div className="chips">{resume.analysis.skills?.map(x=><span key={x}>{x}</span>)}</div></div>}</section>
    <section className="card"><div className="step">02</div><h2>Mock question set</h2>{questions.length ? <ol className="questions">{questions.map((q,i)=><li key={q} onClick={()=>setQuestion(q)}><span>{String(i+1).padStart(2,"0")}</span>{q}</li>)}</ol> : <div className="empty">Upload a resume, enter your target role, and generate a tailored question set.</div>}</section>
    <section className="card wide"><div className="step">03</div><h2>Live practice & coaching</h2><div className="practice"><div><div className="row"><button className={busy==="listening"?"danger":"secondary"} onClick={busy==="listening"?stop:listen}>{busy==="listening"?"■ Stop listening":"● Start microphone"}</button><button className="ghost" disabled={!transcript||!!busy} onClick={()=>detect()}>Detect question</button></div><label>Transcript<textarea rows="5" value={transcript} onChange={e=>setTranscript(e.target.value)} placeholder="Your live transcript appears here…" /></label><label>Detected question<input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="What challenge did you overcome?" /></label><label>Your draft (optional)<textarea rows="4" value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Add the points you want to include…" /></label><button className="primary" disabled={!question||!!busy} onClick={coach}>{busy==="coach"?"Coaching…":"Coach my answer"}</button></div><div className="answer"><span className="eyebrow">COACHING NOTES</span>{answer?<p>{answer}</p>:<div className="empty">Your resume-grounded answer guidance will appear here.</div>}</div></div></section></div>
    <footer>Practice ethically. Get consent before recording or transcribing another person.</footer></main></div>;
}

export default function App() {
  const [authed,setAuthed]=useState(!!localStorage.getItem("token"));
  useEffect(()=>{ const update=()=>setAuthed(!!localStorage.getItem("token")); window.addEventListener("storage",update); window.addEventListener("auth-expired",update); const timer=setInterval(update,500); return()=>{clearInterval(timer);window.removeEventListener("storage",update);window.removeEventListener("auth-expired",update)};},[]);
  const logout=()=>{localStorage.removeItem("token");setAuthed(false)};
  return <Routes><Route path="/login" element={authed?<Navigate to="/"/>:<Auth mode="login"/>}/><Route path="/register" element={authed?<Navigate to="/"/>:<Auth mode="register"/>}/><Route path="/" element={authed?<Dashboard logout={logout}/>:<Navigate to="/login"/>}/><Route path="*" element={<Navigate to="/"/>}/></Routes>;
}

