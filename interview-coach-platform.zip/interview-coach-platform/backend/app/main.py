import io
import json
import os

from docx import Document
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pypdf import PdfReader
from sqlalchemy.orm import Session

load_dotenv()

from .ai import analyze_resume, coach_answer, detect_question, mock_questions
from .auth import create_token, current_user, hash_password, verify_password
from .database import Base, engine, get_db
from .models import Resume, User
from .schemas import AuthRequest, CoachRequest, DetectRequest, QuestionRequest, TokenResponse

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Interview Coach API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("FRONTEND_ORIGIN", "http://localhost:5173")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def latest_resume(db: Session, user: User) -> Resume:
    resume = db.query(Resume).filter(Resume.user_id == user.id).order_by(Resume.created_at.desc()).first()
    if not resume:
        raise HTTPException(status_code=400, detail="Upload a resume first")
    return resume


def extract_text(filename: str, content: bytes) -> str:
    suffix = filename.lower().rsplit(".", 1)[-1]
    if suffix == "pdf":
        return "\n".join(page.extract_text() or "" for page in PdfReader(io.BytesIO(content)).pages)
    if suffix == "docx":
        return "\n".join(p.text for p in Document(io.BytesIO(content)).paragraphs)
    if suffix == "txt":
        return content.decode("utf-8", errors="replace")
    raise HTTPException(status_code=415, detail="Upload a PDF, DOCX, or TXT file")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/auth/register", response_model=TokenResponse, status_code=201)
def register(payload: AuthRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email.lower()).first():
        raise HTTPException(status_code=409, detail="Email is already registered")
    user = User(email=payload.email.lower(), password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return TokenResponse(access_token=create_token(user.id))


@app.post("/auth/login", response_model=TokenResponse)
def login(payload: AuthRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email.lower()).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return TokenResponse(access_token=create_token(user.id))


@app.get("/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "email": user.email}


@app.post("/resume/upload")
async def upload_resume(
    file: UploadFile = File(...),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    content = await file.read()
    if len(content) > 5 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File must be 5 MB or smaller")
    text = extract_text(file.filename or "resume.txt", content).strip()
    if len(text) < 30:
        raise HTTPException(status_code=422, detail="Could not extract enough resume text")
    analysis = analyze_resume(text)
    record = Resume(user_id=user.id, filename=file.filename or "resume", text=text, analysis=json.dumps(analysis))
    db.add(record)
    db.commit()
    return {"filename": record.filename, "analysis": analysis}


@app.get("/resume/latest")
def get_resume(user: User = Depends(current_user), db: Session = Depends(get_db)):
    resume = latest_resume(db, user)
    return {"filename": resume.filename, "analysis": json.loads(resume.analysis or "{}")}


@app.post("/interview/questions")
def questions(payload: QuestionRequest, user: User = Depends(current_user), db: Session = Depends(get_db)):
    resume = latest_resume(db, user)
    return {"questions": mock_questions(resume.text, payload.target_role, payload.count)}


@app.post("/interview/detect-question")
def question_detection(payload: DetectRequest, _: User = Depends(current_user)):
    return detect_question(payload.transcript)


@app.post("/interview/coach")
def coaching(payload: CoachRequest, user: User = Depends(current_user), db: Session = Depends(get_db)):
    resume = latest_resume(db, user)
    return {"answer": coach_answer(resume.text, payload.question, payload.draft_answer, payload.target_role)}

