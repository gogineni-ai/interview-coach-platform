from pydantic import BaseModel, EmailStr, Field


class AuthRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class QuestionRequest(BaseModel):
    target_role: str = Field(default="Software Engineer", max_length=120)
    count: int = Field(default=8, ge=3, le=15)


class CoachRequest(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    draft_answer: str = Field(default="", max_length=6000)
    target_role: str = Field(default="", max_length=120)


class DetectRequest(BaseModel):
    transcript: str = Field(min_length=2, max_length=10000)

