import json
import os
import re

from openai import OpenAI


def _client():
    key = os.getenv("OPENAI_API_KEY")
    return OpenAI(api_key=key) if key else None


def _generate(system: str, prompt: str) -> str | None:
    client = _client()
    if not client:
        return None
    response = client.responses.create(
        model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
        instructions=system,
        input=prompt,
    )
    return response.output_text.strip()


def analyze_resume(text: str) -> dict:
    generated = _generate(
        "You are a precise resume coach. Return valid JSON only with keys summary, skills, strengths, improvements. skills, strengths, and improvements must be arrays of short strings.",
        text[:18000],
    )
    if generated:
        try:
            return json.loads(generated)
        except json.JSONDecodeError:
            pass
    keywords = ["Python", "JavaScript", "React", "FastAPI", "SQL", "AWS", "Machine Learning", "Data Analysis", "Docker", "Git"]
    skills = [skill for skill in keywords if skill.lower() in text.lower()]
    return {
        "summary": "Resume uploaded successfully. Add an OpenAI API key for a deeper tailored analysis.",
        "skills": skills or ["Skills require review"],
        "strengths": ["Provides interview context", "Can ground answers in documented experience"],
        "improvements": ["Quantify outcomes", "Use action verbs", "Tailor the summary and skills to the target role"],
    }


def mock_questions(resume: str, role: str, count: int) -> list[str]:
    generated = _generate(
        f"Create exactly {count} realistic interview questions for a {role}. Ground them in the resume. Return a JSON array of strings only, mixing behavioral and technical questions.",
        resume[:16000],
    )
    if generated:
        try:
            items = json.loads(generated)
            if isinstance(items, list):
                return [str(x) for x in items][:count]
        except json.JSONDecodeError:
            pass
    defaults = [
        f"Tell me about yourself and why you are interested in this {role} role.",
        "Walk me through a challenging project from your resume.",
        "Describe a technical decision you made and the tradeoffs you considered.",
        "Tell me about a time you diagnosed a difficult problem.",
        "How did you measure the impact of your work?",
        "Describe a disagreement with a teammate and how you resolved it.",
        "Which skill on your resume is strongest, and how have you applied it?",
        "What would you improve if you could redo one of your projects?",
        "How do you test and monitor software in production?",
        "Why should we hire you for this role?",
    ]
    return defaults[:count]


def coach_answer(resume: str, question: str, draft: str, role: str) -> str:
    generated = _generate(
        "You are an interview coach. Write a natural first-person answer based only on evidence in the resume. Do not invent facts. Use a concise STAR structure when relevant, target 90-150 spoken words, and end with one coaching tip.",
        f"ROLE: {role}\nQUESTION: {question}\nDRAFT: {draft}\nRESUME:\n{resume[:16000]}",
    )
    if generated:
        return generated
    context = re.sub(r"\s+", " ", resume).strip()[:500]
    return (
        f"Start with a direct answer to: “{question}” Then use one specific example from your experience. "
        "Explain the situation and your responsibility, describe the actions you personally took, and close with a measurable result or lesson. "
        f"Resume evidence you can draw from: {context}\n\nCoaching tip: keep the response under two minutes and never add experience that is not on your resume."
    )


def detect_question(transcript: str) -> dict:
    cleaned = re.sub(r"\s+", " ", transcript).strip()
    parts = re.split(r"(?<=[?.!])\s+", cleaned)
    cues = ("what", "why", "how", "when", "where", "who", "which", "tell me", "describe", "explain", "walk me", "can you", "could you", "have you")
    candidates = [p for p in parts if p.endswith("?") or p.lower().startswith(cues)]
    question = candidates[-1] if candidates else ""
    return {"is_question": bool(question), "question": question}

